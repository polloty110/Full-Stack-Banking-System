/**
 * 
 */

console.log("hello!");


window.onload = function() {
	 console.log("start");
	// getllUsers();
	document.getElementById("register").addEventListener('click', register);
}

function register(event) {


		event.preventDefault();
	

		var formData = new FormData();
		
		var customername  = document.getElementsByName("user")[0].value;
		var password  = document.getElementsByName("user")[1].value;
		var firstname = document.getElementsByName("user")[2].value;
		var lastname  = document.getElementsByName("user")[3].value;
		var email 	  = document.getElementsByName("user")[4].value;
		 
		 
		 
		 
		 
		 formData.append("customername", customername);
		 formData.append("password", password); 
		 formData.append("firstname", firstname);
		 formData.append("lastname", lastname); 
		 formData.append("email", email); 
	   
		const url = "signup";
	    let xhttp = new XMLHttpRequest();
	    xhttp.open("POST", url);
	    xhttp.send(formData);
	    window.location.href="http://localhost:9000/login.html";

}






