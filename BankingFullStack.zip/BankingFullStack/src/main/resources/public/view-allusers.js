/**
 * 
 */

console.log("hello!");


function getllAccounts(userid) {



	let xhr = new XMLHttpRequest();

	//1 const url = "localhost:9000/planet"

	//2 http://localhost:9000/view-planets.html
	const url = "users";

	var formData = new FormData();
	formData.append("userid", userid);
	xhr.onreadystatechange = function() {

		console.log("hi!");

		switch (xhr.readyState) {

			case 0:
				console.log("nothing, not initalized yet!");
				break;
			case 1:
				console.log("connection established");
				break;
			case 2:
				console.log("request sent");
				break;
			case 3:
				console.log("awaiting request");
				break;
			case 4:
				console.log("FINISHED!!!!")

				if (xhr.status == 418) {
					console.log(xhr.responseText);

					let accountList = JSON.parse(xhr.responseText);

					console.log(accountList);

					var tb = document.getElementById("account-table");
					var rowNum = tb.rows.length;
					for (i = 0; i < rowNum; i++) {
						tb.deleteRow(i);
						rowNum = rowNum - 1;
						i = i - 1;
					}

					var oHead = document.createElement("thead");
					var oTr = document.createElement("tr");
					tb.appendChild(oHead);
					oHead.appendChild(oTr);



					let id = document.createElement("th");
					let accountname = document.createElement("th");
					let balance = document.createElement("th");
					let approve = document.createElement("th");



					id.textContent = "ID";
					accountname.textContent = "Account name";
					balance.textContent = "Balance";
					approve.textContent = "approval or not";

					oTr.appendChild(id);
					oTr.appendChild(accountname);
					oTr.appendChild(balance);
					oTr.appendChild(approve);



					accountList.forEach(
						element => {
							addRowAgain(element, tb);
						}

					)
				}
		}



	}

	xhr.open("POST", url);
	xhr.send(formData);
}


function addRowAgain(accounts, table) {

	let tableRow = document.createElement("tr");
	let iDCol = document.createElement("td");
	let nameCol = document.createElement("td");
	let descriptionCol = document.createElement("td");
	let approve = document.createElement("td");
	//let deleteCol = document.createElement("td");



	tableRow.appendChild(iDCol);
	tableRow.appendChild(nameCol);
	tableRow.appendChild(descriptionCol);
	tableRow.appendChild(approve);
	//tableRow.appendChild(deleteCol);

	table.appendChild(tableRow);

	iDCol.innerHTML = accounts.accountID;
	nameCol.innerHTML = accounts.accountName;
	descriptionCol.innerHTML = accounts.banlance;
	if (accounts.approve == 0) {
		approve.innerHTML = "Waiting for approving";
	} else {
		approve.innerHTML = "approved";
	}
	//deleteCol.innerHTML = `<button id = "${accounts.accountID}" type="submit" class="btn btn-primary">Approval</button>`;

	//document.getElementById(accounts.accountID).addEventListener('click', approved(accounts.accountID));

};

function approved(event) {

	event.preventDefault();

	console.log("haha");

	var formData = new FormData();
	var accountID = document.getElementsByName("approvalname")[0].value;

	formData.append("accountID", accountID);
	const url = "approval";
	let xhttp = new XMLHttpRequest();
	xhttp.open("PUT", url);
	xhttp.send(formData);




	var str = "mailto:";

	var userid = document.getElementsByName("userid")[0].value;
	var tb = document.getElementById('users-table');
	var rows = tb.rows;
	for (var i = 1; i < rows.length; i++) {
		if (rows[i].cells[0].innerHTML == userid) {
			str = str + rows[i].cells[4].innerHTML + "?" + 
			"subject=test&cc=polloty110@gmail.com&subject=" + "bank account"+ "&body="  + "your new account is approved!";
			i = rows.length;

		}
	}

		location=str;
	window.location.href = "http://localhost:9000/view-allusers.html";
};


function checkAllUsers(event) {
	event.preventDefault();
	window.onload.href = "http://localhost:9000/view-allusers.html";
};

function checkUser(event) {
	event.preventDefault();
	getllAccounts(document.getElementsByName("userid")[0].value);


};







window.onload = function() {
	console.log("start");
	getllUsers();
	document.getElementById("check").addEventListener('click', checkUser);
	document.getElementById("approval").addEventListener('click', approved);
}

function getllUsers() {

	let xhr = new XMLHttpRequest();

	//1 const url = "localhost:9000/planet"

	//2 http://localhost:9000/view-planets.html
	const url = "users";

	xhr.onreadystatechange = function() {

		console.log("hi!");

		switch (xhr.readyState) {

			case 0:
				console.log("nothing, not initalized yet!");
				break;
			case 1:
				console.log("connection established");
				break;
			case 2:
				console.log("request sent");
				break;
			case 3:
				console.log("awaiting request");
				break;
			case 4:
				console.log("FINISHED!!!!")

				if (xhr.status == 418) {
					console.log(xhr.responseText);

					let accountList = JSON.parse(xhr.responseText);

					console.log("123454");
					console.log(accountList);
					console.log("543534254");

					accountList.forEach(
						element => {
							addRow(element);
						}
					)
				}
		}
	}

	xhr.open("GET", url);
	xhr.send();
}

function addRow(users) {


	let table = document.getElementById("users-table");


	let tableRow = document.createElement("tr");
	let id = document.createElement("td");
	let user_name = document.createElement("td");
	let firstName = document.createElement("td");
	let lastName = document.createElement("td");
	let user_email = document.createElement("td");



	tableRow.appendChild(id);
	tableRow.appendChild(user_name);
	tableRow.appendChild(firstName);
	tableRow.appendChild(lastName);
	tableRow.appendChild(user_email);

	table.appendChild(tableRow);

	id.innerHTML = users.id;
	user_name.innerHTML = users.user_name;
	firstName.innerHTML = users.firstName;
	lastName.innerHTML = users.lastName;
	user_email.innerHTML = users.user_email;

};

