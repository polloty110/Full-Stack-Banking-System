/**
 * 
 */

console.log("hello!");


function testWithdraw(account_id,amount) {
	console.log("1");
	var tb = document.getElementById('account-table');
	var rows = tb.rows;
	for (var i = 1; i < rows.length; i++) {
		if (rows[i].cells[0].innerHTML == account_id) {
			var currentBalance = rows[i].cells[2].innerHTML;

			if (eval(amount) > eval(currentBalance)) {
				console.log(amount);
				console.log(currentBalance);
				alert("Insufficient balance, please try again!");
				return false;
			} else {
				return true;
			}
		}     
	}


}

function withdrawalAmount(event) {
	event.preventDefault();

	var value = document.getElementById("amount").value;
	if (testAmount(value)) {
		
			var account_id = document.getElementsByName("account_id")[0].value;
			var amount = document.getElementsByName("amount")[0].value;
		
		if(testWithdraw(account_id, amount)) {
		
			var formData = new FormData();
		 var account_id = document.getElementsByName("account_id")[0].value;
		 var amount = document.getElementsByName("amount")[0].value;
		 var amount = -1*amount;
		 formData.append("accounts_id", account_id);
		 formData.append("amount", amount); 
	   
		const url = "customer";
	    let xhttp = new XMLHttpRequest();
	    xhttp.open("PUT", url);
	    xhttp.send(formData);
	    window.location.href="http://localhost:9000/view-customer.html";
		}
		


	}






}

function depositAmount(event) {
	event.preventDefault();
	var value = document.getElementById("amount").value;
	
	if (testAmount(value)) {
		var formData = new FormData();
		 var account_id = document.getElementsByName("account_id")[0].value;
		 var amount = document.getElementsByName("amount")[0].value;
		 formData.append("accounts_id", account_id);
		 formData.append("amount", amount); 
	   
		const url = "customer";
	    let xhttp = new XMLHttpRequest();
	    xhttp.open("PUT", url);
	    xhttp.send(formData);
	    window.location.href="http://localhost:9000/view-customer.html";
	}

}


function transferAmount() {
	//event.preventDefault();
	 console.log("1");
	var value = document.getElementById("currentAmount").value;
	if (testAmount(value)) {
		
		
		
		var currentAccount_id = document.getElementsByName("currentAccount_id")[0].value;
		var currentAmount = document.getElementsByName("currentAmount")[0].value;
		
		if(testWithdraw(currentAccount_id, currentAmount)) {
			
			var formData = new FormData();
			 var currentAccount_id = document.getElementsByName("currentAccount_id")[0].value;
			 var currentAmount = document.getElementsByName("currentAmount")[0].value;
			 var anotherAccount_id = document.getElementsByName("anotherAccount_id")[0].value;
			 formData.append("currentAccount_id", currentAccount_id);
			 formData.append("currentAmount", currentAmount); 
			 formData.append("anotherAccount_id", anotherAccount_id); 
	   
			const url = "transferAcount";
		    let xhttp = new XMLHttpRequest();
		    xhttp.open("POST", url);
		    xhttp.send(formData);
		window.location.href="http://localhost:9000/view-customer.html";
		}
		window.location.href="http://localhost:9000/view-customer.html";
		
	}
		window.location.href="http://localhost:9000/view-customer.html";

}




window.onload = function() {
	//console.log("Inside onload function!");
	 console.log("start");
	getllAccounts();
	document.getElementById("withdrawal").addEventListener('click', withdrawalAmount);
	document.getElementById("deposit").addEventListener('click', depositAmount);
	document.getElementById("transfer").addEventListener('click', transferAmount);


}

function getllAccounts() {

	let xhr = new XMLHttpRequest();

	//1 const url = "localhost:9000/planet"

	//2 http://localhost:9000/view-planets.html
	const url = "customer";

	xhr.onreadystatechange = function() {

		console.log("hi!");

		switch (xhr.readyState) {

			case 0:
				console.log("nothing, not initalized yet!");
				break;
			case 1:
				console.log("connection established");
				break;
			case 2:
				console.log("request sent");
				break;
			case 3:
				console.log("awaiting request");
				break;
			case 4:
				console.log("FINISHED!!!!")

				if (xhr.status == 418) {
					console.log(xhr.responseText);

					let accountList = JSON.parse(xhr.responseText);

					console.log(accountList);

					accountList.forEach(
						element => {
							addRow(element);
						}

					)
				}
		}



	}

	xhr.open("GET", url);
	xhr.send();
}



function testAmount(value) {

	console.log("test amount: " + value);
	if (value < 0) {
		alert("Please enter the correct amount!");
		return false;
	}
	return true;
}





function addRow(accounts) {


	let table = document.getElementById("account-table");


	let tableRow = document.createElement("tr");
	let iDCol = document.createElement("td");
	let nameCol = document.createElement("td");
	let descriptionCol = document.createElement("td");



	tableRow.appendChild(iDCol);
	tableRow.appendChild(nameCol);
	tableRow.appendChild(descriptionCol);

	table.appendChild(tableRow);

	iDCol.innerHTML = accounts.accountID;
	nameCol.innerHTML = accounts.accountName;
	descriptionCol.innerHTML = accounts.banlance;

};

