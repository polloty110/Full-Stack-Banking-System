package com.revature;


import com.revature.controller.AuthController;


import com.revature.controller.AuthControllerImpl;
import com.revature.controller.AuthEmployeeController;
import com.revature.controller.AuthEmployeeControllerImpl;
import com.revature.controller.CustomerController;
import com.revature.controller.CustomerControllerImpl;
import com.revature.controller.UsersController;
import com.revature.controller.UsersControllerImpl;
import com.revature.util.ConnectionDriver;

import io.javalin.Javalin;




public class MainDriver {
	private static final String LOGIN_PATH = "/login";
	private static AuthController authController = new AuthControllerImpl();
	
	private static AuthEmployeeController authEmployeeController = new AuthEmployeeControllerImpl();
	private static final String CUSTOMER_PATH = "/customer";
	private static CustomerController customerController = new CustomerControllerImpl();
	
	
	private static UsersController usersController = new UsersControllerImpl();
	public static void main(String[] args) {

		ConnectionDriver.getConnection();
		Javalin app = Javalin.create(
				config -> {
					config.addStaticFiles("/public");
				}).start(9000);
		// login with customer
		app.post(LOGIN_PATH, ctx -> authController.customerLogin(ctx));
		
		app.get("/logout", ctx -> authController.customerLogout(ctx));
		//app.get("/checkUser", ctx -> authController.checkUser(ctx));
		
		//logoutemployee
		app.post("/employeelogin", ctx -> authEmployeeController.employeeLogin(ctx));
		app.get("/logoutemployee", ctx -> authEmployeeController.employeeLogout(ctx));
		
		app.get("/users", ctx -> usersController.getAllUsers(ctx));
		
		app.put("/approval", ctx -> usersController.approvedAccounts(ctx));
		
		
		app.post(CUSTOMER_PATH, ctx -> customerController.postAccount(ctx));
		app.get(CUSTOMER_PATH, ctx -> customerController.getAllAccounts(ctx));
		
		app.post("/signup", ctx -> usersController.postUsers(ctx));
		//app.get("/signup", ctx -> customerController.getAllAccounts(ctx));
		app.post("/users", ctx -> customerController.getAllAccountsUsers(ctx));
		
		
		app.put(CUSTOMER_PATH, ctx -> customerController.putAccount(ctx));
		
		app.post("/transferAcount", ctx-> customerController.updateTransferAccount(ctx));
	}

}
