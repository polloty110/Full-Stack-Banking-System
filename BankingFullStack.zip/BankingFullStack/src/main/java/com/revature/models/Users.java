package com.revature.models;


public class Users {

	private int ID;
	private String user_name;
	private String user_password;
	private String firstName;
	private String lastName;
	private String user_email;

	public Users(int iD, String user_name, String user_password, String firstName, String lastName, String user_email) {
		super();
		ID = iD;
		this.user_name = user_name;
		this.user_password = user_password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.user_email = user_email;
	}

	@Override
	public String toString() {
		return ID + ") user_name: " + user_name + ", firstName: " + firstName + ", lastName: " + lastName;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getUser_password() {
		return user_password;
	}

	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

}
