package com.revature.dao;


public interface EmployeesDao {

	
	


	
	//READ
	 boolean selectByUsernamePasswords(String userName, String Passwords);


	 

}
