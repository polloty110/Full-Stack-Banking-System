package com.revature.exception;

public class NullUserNameException extends Exception{
	

}
