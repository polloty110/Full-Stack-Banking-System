package com.revature.exception;

public class UserNotExistsException extends Exception {

}
