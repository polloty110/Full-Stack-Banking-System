package com.revature.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

import com.revature.dao.EmployeesDao;
import com.revature.dao.EmployeesDaoImpl;
import com.revature.dao.UsersDao;
import com.revature.dao.UsersDaoImpl;
import com.revature.models.Users;

public class AuthEmployeeServiceImpl implements AuthEmployeeService {



	
	
	EmployeesDao eDao = new EmployeesDaoImpl();
	
	public static String[] tempEmployee = null;


	

	@Override
	public boolean authenticateUser(String username, String password) {

		Boolean  isExisted = eDao.selectByUsernamePasswords(username, password);
		tempEmployee = null;
		// checking if user exists with that username
		if (isExisted) {
			tempEmployee = new String[]{username,password};
			return true;
		}
		return false;

	}






}
