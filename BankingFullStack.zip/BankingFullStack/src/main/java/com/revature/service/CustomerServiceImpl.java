package com.revature.service;

import java.util.List;

import com.revature.dao.AccountsDao;
import com.revature.dao.AccountsDaoImpl;
import com.revature.dao.UsersDao;
import com.revature.dao.UsersDaoImpl;
import com.revature.models.Accounts;
import com.revature.models.Users;

public class CustomerServiceImpl implements CustomerService {

	
	//AuthServiceImpl
	
	AccountsDao accountsDao = new AccountsDaoImpl();
	@Override
	public List<Accounts> getAllAccounts(String userName) {
		UsersDao userDao = new UsersDaoImpl();
		Users tempUser = userDao.selectUserByUsername(userName);
		List<Accounts> accountList = accountsDao.selectAccountsByUserId(tempUser.getID());

		return accountList;
	}
	

	@Override
	public List<Accounts> getAllAccountsByUserId(int userid) {
		List<Accounts> accountList = accountsDao.selectAccountsByUserId(userid);

		return accountList;
	}

	@Override
	public Accounts getAccountByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean createAccount(Accounts newPlanet) {
		return accountsDao.createAccount(newPlanet);
	}

	@Override
	public boolean deleteAccount(Accounts deletePlanet) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateAccount(Accounts p, double amount) {
		// TODO Auto-generated method stub
		return accountsDao.updateAccounts(p, amount);
	}


}
