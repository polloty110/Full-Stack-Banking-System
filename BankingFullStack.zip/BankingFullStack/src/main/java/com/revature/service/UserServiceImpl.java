package com.revature.service;


import java.util.List;

import com.revature.dao.AccountsDao;
import com.revature.dao.AccountsDaoImpl;
import com.revature.dao.UsersDao;
import com.revature.dao.UsersDaoImpl;
import com.revature.models.Users;

public class UserServiceImpl implements UserService {

	
	UsersDao usersDao = new UsersDaoImpl();
	@Override
	public boolean createUser(Users newUser) {
		
		return usersDao.createUser(newUser);
	}
	@Override
	public List<Users> selectAllUsers() {

		return usersDao.selectAllUsers();
	}
	@Override
	public boolean approvedAccounts(int accountid) {
		
		AccountsDao accountDao = new AccountsDaoImpl();
		return accountDao.approveAccounts(accountid);

	}
	
	
	
}
