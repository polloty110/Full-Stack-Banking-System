package com.revature.service;



public interface AuthEmployeeService {

	public boolean authenticateUser(String username, String password);
	
	

}
