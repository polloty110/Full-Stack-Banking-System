package com.revature.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

import com.revature.dao.UsersDao;
import com.revature.dao.UsersDaoImpl;
import com.revature.models.Users;

public class AuthServiceImpl implements AuthService {

	private static byte[] salt = new SecureRandom().getSeed(16);

	private Map<String, String> tokenList = new HashMap<>();

	UsersDao uDao = new UsersDaoImpl();
	
	public static Users tempUser = null;


	

	@Override
	public boolean authenticateUser(String username, String password) {

		Users u = uDao.selectUserByUsername(username);
		tempUser = null;
		// checking if user exists with that username
		if (u == null) {
			return false;
		} else {
			// chekcing if that user password matches.
			if (password.equals(u.getUser_password())) {
				tempUser = u;
				return true;
			}
		}

		return false;

	}

	@Override
	public String createToken(String username) {
		String token = encryptionHash(username);
		 tokenList.put(token, username);
		 return token;

	}

	private String encryptionHash(String username) {
		String hash = null;
		
		MessageDigest md;
		
		try {
			md = MessageDigest.getInstance("SHA-512");
			
			md.update(salt);
			
			byte[] bytes = md.digest(username.getBytes());
			
			StringBuilder sb = new StringBuilder();
			
			for(int i = 0; i < bytes.length; i++) {
				sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(0));
			}
			
			hash = sb.toString();
			
			
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return hash;
	}

	@Override
	public boolean validateToken(String token) {
		return tokenList.containsKey(token);
	}

}
