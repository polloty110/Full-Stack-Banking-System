package com.revature.service;


import java.util.List;

import com.revature.models.Users;

public interface UserService {
	
	public boolean createUser(Users newUser);
	
	
	public List<Users> selectAllUsers();
	
	
	public boolean approvedAccounts(int accountid);

}
