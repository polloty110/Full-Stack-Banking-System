package com.revature.service;

import java.util.List;

import com.revature.models.Accounts;



public interface CustomerService {
	
	
	
	public List<Accounts> getAllAccountsByUserId(int userid);
	
	public List<Accounts> getAllAccounts(String userName);
	
	public Accounts getAccountByName(String name);

	public boolean createAccount(Accounts newPlanet);
	
	public boolean deleteAccount(Accounts deletePlanet);
	
	public boolean updateAccount(Accounts p,double amount);

}
