package com.revature.controller;

import org.apache.log4j.Logger;

import com.revature.service.AuthService;
import com.revature.service.AuthServiceImpl;

import io.javalin.http.Context;

public class AuthControllerImpl implements AuthController {
	
	private AuthService authService = new AuthServiceImpl();
	
	final static Logger logger = Logger.getLogger(AuthControllerImpl.class.getName());

	@Override
	public void customerLogin(Context ctx) {
		String username = ctx.formParam("username");
		String password = ctx.formParam("password");
		

		
		if(authService.authenticateUser(username, password)) {
			
			logger.info("success: username " + username + ", password: " + password);
			ctx.status(200);
			//	ctx.cookieStore(username,authService.createToken(username));
			ctx.redirect("view-customer.html");
		}else {
			
			logger.warn("failed: username " + username + ", password: " + password);
			ctx.status(507);
			ctx.redirect("login.html");
		}
		
		System.out.println("username: " + username + ",  password: " + password);
		System.out.println();

	}



	@Override
	public void customerLogout(Context ctx) {
		//ctx.clearCookieStore();
		AuthServiceImpl.tempUser = null;
		System.out.println("hi! customer Logout");
		logger.info("hi! customer Logout");
		ctx.redirect("login.html");
		
	}



	@Override
	public boolean checkUser(Context ctx) {
		
		return authService.validateToken(ctx.cookieStore("user"));
	}

}
