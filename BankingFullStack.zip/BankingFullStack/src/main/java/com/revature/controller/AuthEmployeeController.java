package com.revature.controller;

import io.javalin.http.Context;

public interface AuthEmployeeController {
	
	public void employeeLogin(Context ctx);
	
	public void employeeLogout(Context ctx);
	


	boolean checkUser(Context ctx);

}
