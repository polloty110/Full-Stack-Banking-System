package com.revature.controller;

import io.javalin.http.Context;

public interface UsersController {
	
	

	public void getAllUsers(Context ctx);
	
	
	public void postUsers(Context ctx);
	
	
	public void putUsers(Context ctx);
	
	public void approvedAccounts(Context ctx);
	
	//public void deleteUsersWithJSON(Context ctx);
	
	//public void deleteUsers(Context ctx);





}
