package com.revature.controller;
import com.revature.models.Users;
import com.revature.service.AuthEmployeeServiceImpl;
import com.revature.service.AuthServiceImpl;
import com.revature.service.UserService;
import com.revature.service.UserServiceImpl;

import io.javalin.http.Context;

public class UsersControllerImpl implements UsersController {


	
	UserService userService = new UserServiceImpl();
	
	

	@Override
	public void approvedAccounts(Context ctx) {
		
		
		System.out.println("get add new User!");
		int accountID = Integer.parseInt(ctx.formParam("accountID"));
		
		userService.approvedAccounts(accountID);
		
	}
	
	
	
	
	@Override
	public void getAllUsers(Context ctx) {
		

		System.out.println("get all users!!!!");
		if (AuthEmployeeServiceImpl.tempEmployee != null) {
			ctx.status(418);
			System.out.println(AuthEmployeeServiceImpl.tempEmployee[0] + ": userName");
			ctx.json(userService.selectAllUsers());
		} else {
			System.out.println("please login!");
		}
		
		
		
	}

	
	
	
	@Override
	public void postUsers(Context ctx) {

		System.out.println("get add new User!");
		String customername = ctx.formParam("customername");
		String password = ctx.formParam("password");
		String firstname = ctx.formParam("firstname");
		String lastname = ctx.formParam("lastname");
		String email = ctx.formParam("email");
		
		Users tempU = new Users(0,customername,password,firstname,lastname, email);
		
		if (userService.createUser(tempU)) {
			ctx.status(201);
			ctx.redirect("http://localhost:9000/login.html");
		} else {
			ctx.status(506);
		}

	}

	@Override
	public void putUsers(Context ctx) {
		// TODO Auto-generated method stub

	}





}
