package com.revature.controller;

import io.javalin.http.Context;

public interface CustomerController {
	
	
	public void getAllAccountsUsers(Context ctx);
	
	public void getAllAccounts(Context ctx);
	
	
	public void postAccount(Context ctx);
	
	
	public void putAccount(Context ctx);
	
	public void updateTransferAccount(Context ctx);
	
	//public void deletePlanetWithJSON(Context ctx);
	
	//public void deleteAccounts(Context ctx);



}
