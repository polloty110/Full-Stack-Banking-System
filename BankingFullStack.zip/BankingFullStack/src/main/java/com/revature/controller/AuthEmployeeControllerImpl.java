package com.revature.controller;

import org.apache.log4j.Logger;

import com.revature.service.AuthEmployeeService;
import com.revature.service.AuthEmployeeServiceImpl;
import com.revature.service.AuthService;
import com.revature.service.AuthServiceImpl;

import io.javalin.http.Context;

public class AuthEmployeeControllerImpl implements AuthEmployeeController {
	
	final static Logger logger = Logger.getLogger(AuthEmployeeControllerImpl.class.getName());
	
	private AuthEmployeeService authEmployeeService = new AuthEmployeeServiceImpl();
	
	

	@Override
	public void employeeLogin(Context ctx) {
		String username = ctx.formParam("username");
		String password = ctx.formParam("password");
		

		
		if(authEmployeeService.authenticateUser(username, password)) {
			ctx.status(200);
			
			logger.info("success: username " + username + ", password: " + password);
			//	ctx.cookieStore(username,authService.createToken(username));
			ctx.redirect("view-allusers.html");
		}else {
			logger.info("failed: username " + username + ", password: " + password);
			ctx.status(507);
			ctx.redirect("employeelogin.html");
		}
		
		System.out.println("username: " + username + ",  password: " + password);
		System.out.println();

	}



	@Override
	public void employeeLogout(Context ctx) {
		//ctx.clearCookieStore();
		AuthEmployeeServiceImpl.tempEmployee = null;
		System.out.println("hi! enployee Logout");
		logger.info("hi! enployee Logout");
		ctx.redirect("employeelogin.html");
	}



	@Override
	public boolean checkUser(Context ctx) {
		
		return false;
	}

}
