package com.revature.controller;

import org.apache.log4j.Logger;

import com.revature.dao.AccountsDao;
import com.revature.dao.AccountsDaoImpl;
import com.revature.dao.UsersDao;
import com.revature.dao.UsersDaoImpl;
import com.revature.models.Accounts;
import com.revature.models.Users;
import com.revature.service.AuthServiceImpl;
import com.revature.service.CustomerService;
import com.revature.service.CustomerServiceImpl;

import io.javalin.http.Context;

public class CustomerControllerImpl implements CustomerController {

	private CustomerService CustomerService = new CustomerServiceImpl();
	final static Logger logger = Logger.getLogger(CustomerControllerImpl.class.getName());

	// private AuthController authController = new AuthControllerImpl();

	@Override
	public void getAllAccounts(Context ctx) {

		/*
		 * if (authController.checkUser(ctx)) {
		 * System.out.print("CustomerServiceImpl get infdsfasd"); ctx.status(418);
		 * ctx.json(CustomerService.getAllAccounts(ctx.formParam("username"))); }
		 */

		System.out.println("get all accounts!!!!");
		if (AuthServiceImpl.tempUser != null) {
			ctx.status(418);
			String userName = AuthServiceImpl.tempUser.getUser_name();
			logger.info(userName + ": userName");
			logger.info(CustomerService.getAllAccounts(userName).toString());
			ctx.json(CustomerService.getAllAccounts(userName));
		} else {
			logger.warn("warning: please login!");
			System.out.println("please login!");
		}

	}

	@Override
	public void getAllAccountsUsers(Context ctx) {
		
		System.out.println("get all accounts from users!!!!");
		if (ctx.formParam("userid") != null) {
			Integer user_id =  Integer.parseInt(ctx.formParam("userid"));
			ctx.status(418);
			logger.info(user_id + "   : user_id");
			ctx.json(CustomerService.getAllAccountsByUserId(user_id));
		} else {
			logger.warn("warning: please login!");
		}

	}

	@Override
	public void postAccount(Context ctx) {

		System.out.println("get add method!");
		UsersDao userDao = new UsersDaoImpl();

		int userid = AuthServiceImpl.tempUser.getID();

		String account_name = ctx.formParam("account_name");
		double account_banlance = Double.parseDouble(ctx.formParam("account_banlance"));

		Accounts newAccount = new Accounts(0, account_name, account_banlance, false, userid);

		if (CustomerService.createAccount(newAccount)) {
			ctx.status(201);
			ctx.redirect("http://localhost:9000/view-customer.html");
		} else {
			ctx.status(506);
		}

	}

	@Override
	public void putAccount(Context ctx) {

		System.out.println("get update method!");
		AccountsDao accountsDao = new AccountsDaoImpl();

		// withdrawal && deposit
		int accounts_id = Integer.parseInt(ctx.formParam("accounts_id"));
		double amount = Double.parseDouble(ctx.formParam("amount"));
		Accounts currentAccount = accountsDao.selectAccountByAccountId(accounts_id);

		if (CustomerService.updateAccount(currentAccount, amount)) {
			ctx.status(201);
			ctx.redirect("http://localhost:9000/view-customer.html");
		} else {
			ctx.status(506);
		}

	}

	@Override
	public void updateTransferAccount(Context ctx) {
		System.out.println("get update method transfer!");
		AccountsDao accountsDao = new AccountsDaoImpl();

		int currentAccount_id = Integer.parseInt(ctx.formParam("currentAccount_id"));
		double amount = Double.parseDouble(ctx.formParam("currentAmount"));
		int anotherAccount_id = Integer.parseInt(ctx.formParam("anotherAccount_id"));
		double currentAmount = amount * (-1);

		Accounts currentAccount = accountsDao.selectAccountByAccountId(currentAccount_id);
		Accounts anotherAccount = accountsDao.selectAccountByAccountId(anotherAccount_id);

		if (CustomerService.updateAccount(currentAccount, currentAmount)
				&& CustomerService.updateAccount(anotherAccount, amount)) {
			System.out.println("get update method transfer!!!!!!!");
			ctx.status(201);
			ctx.redirect("http://localhost:9000/view-customer.html");
		} else {
			ctx.status(506);
		}

	}

}
