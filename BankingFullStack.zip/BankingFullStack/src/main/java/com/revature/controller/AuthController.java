package com.revature.controller;

import io.javalin.http.Context;

public interface AuthController {
	
	public void customerLogin(Context ctx);
	
	public void customerLogout(Context ctx);
	


	boolean checkUser(Context ctx);

}
